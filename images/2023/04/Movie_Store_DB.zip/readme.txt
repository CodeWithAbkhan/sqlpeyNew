
/*******************************************************************************
   Script: movie_PostgreSql.sql
   Description: Creates and populates the movie_store database.
   DB Server: PostgreSql
  
********************************************************************************/

- > Recommended if you are Following PostgreSQL Learning tutorial on Codepey  Youtube Channel
- > Open this SQL Query file in PgAdmin and Execute.